import os
from urllib import response

import pymongo
from pymongo import MongoClient
from rest_framework import status
from rest_framework.response import Response

from utils.check_data import check_presence

from utils.mongo_function import connect




class child_details:
    def __init__(self, first_name,last_name,email,user_name,password,mobilenumber,city,nationality,maritial_status,gender):

        self.first_name=first_name
        self.last_name=last_name
        self.email=email
        self.user_name = user_name
        self.password=password
        self.mobilenumber=mobilenumber
        self.city=city
        self.nationality=nationality
        self.maritial_status=maritial_status
        self.gender=gender

    
    def insert_data(self,db): #insertion function
        mylist=[
            {'first_name':self.first_name,'last_name':self.last_name,'email':self.email, 'user_name' : self.user_name,'password':self.password,'mobilenumber':self.mobilenumber, 'city':self.city, 'nationality':self.nationality,'maritial_status':self.maritial_status,'gender':self.gender},
        ]
        db.registration_details.insert_many(mylist)
    
    

 
def post_registration_data(request):
    """
    Updating the major information of a particular child and update the stage to student_full_details/guardian_information depending on the guardian details presence

    Request.body need to have :
    parent_id
    student_id
    class_no
    section
    date_of_birth
    blood_group
    emergency_contact_no
    student_aadhar
    student_school_id
    student_profile

    Return
    status        : True/False depending on the successful execution of the request
    message       : Informative message, describing the response
    student_id    : ID against which the data has been updated
    upload_status : List containing the upload status of all the media files
    """




    res, message = check_presence(request, ["first_name","last_name","email","user_name","password","mobilenumber","city","nationality","maritial_status","gender"
])

    if not res:
        return Response({'status' : False, 'message' : message}, status = 400)
    first_name = request.data.get('first_name')
    last_name = request.data.get('last_name')
    email = request.data.get('email')
    user_name = request.data.get('user_name')
    password=request.data.get('password')
    mobilenumber = request.data.get('mobilenumber')
    city = request.data.get('city')
    nationality = request.data.get('nationality')
    maritial_status = request.data.get('maritial_status')
    gender = request.data.get('gender')
    #
    print(res)
  
    try:
        client = connect()
       
    except:
       
        return Response({'status' : False, 'message' : 'Error in connecting with database'}, 502)

    db = client.quiz  # database name  

    new_child = child_details(first_name,last_name,email,user_name,password,mobilenumber,city,nationality,maritial_status,gender)
    new_child.insert_data(db)
    return Response("register success !",status=200)