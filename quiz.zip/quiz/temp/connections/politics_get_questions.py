import os
from urllib import response


from rest_framework import status
from rest_framework.response import Response

from utils.check_data import check_presence

from utils.mongo_function import connect


class child_details:
    def get_data(self,db): #insertion function
        data=db.politics.find()
        temp=[]
        for datas in data:
            temp.append(datas["user_name"])
        return temp    
    
def get_questions_data(request):
    
    #used based on requirement
    # res, message = check_presence(request, ["name"])

    # if not res:
    #     return Response({'status' : False, 'message' : message}, status = 400)
    # name = request.data.get('name')
    # print(res)
  
    try:
        client = connect()
       
    except:
       
        return Response({'status' : False, 'message' : 'Error in connecting with database'}, 502)

    db = client.quiz   # database name  

    new_child = child_details()
    get_details=new_child.get_data(db)
    #s=''
    #for i in range(len(get_details)):
    #s=get_details[0]+os.linesep+get_details[1]
        
        
    return Response(get_details,status=200)
