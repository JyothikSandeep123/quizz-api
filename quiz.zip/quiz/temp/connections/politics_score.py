import os
from urllib import response


from rest_framework import status
from rest_framework.response import Response

from utils.check_data import check_presence

from utils.mongo_function import connect


class child_details:
    def get_data(self,db): #insertion function
        data=db.politics_user_answers.find()
        user_data=db.politics.find()
        temp=[]
        ans=[]
        for datas in data:
            temp.append(datas["question"])
        for user in user_data:
            ans.append(user["password"])
        count=0    
        for i in range(len(temp)):
            if(temp[i]==ans[i]):
                count=count+1        
        return count    
    
def get_answers_data(request):
    
    #used based on requirement
    # res, message = check_presence(request, ["name"])

    # if not res:
    #     return Response({'status' : False, 'message' : message}, status = 400)
    # name = request.data.get('name')
    # print(res)
  
    try:
        client = connect()
       
    except:
       
        return Response({'status' : False, 'message' : 'Error in connecting with database'}, 502)

    db = client.quiz   # database name  

    new_child = child_details()
    get_details=new_child.get_data(db)
    return Response(get_details,status=200)
