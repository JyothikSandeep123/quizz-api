from django.contrib import admin
from django.urls import path,include
from django.views.decorators.csrf import csrf_exempt
from temp.views import delete_account, field_data, question_data,user_field_data
from temp.views import answer_data
from temp.views import questions_get_data
from temp.views import user_answers1
from temp.views import marks_data
from temp.views import login
from temp.views import registration
from temp.views import registration_login_data
from temp.views import politics
from temp.views import politics_get_questions
from temp.views import politics_answers
from temp.views import politics_data
urlpatterns = [
    path('answer_data/',csrf_exempt(answer_data.as_view())),
    path('question_data/',csrf_exempt(question_data.as_view())),
    path('questions_get_data/',csrf_exempt(questions_get_data.as_view())),
    path('user_answers1/',csrf_exempt(user_answers1.as_view())),
    path('marks_data/',csrf_exempt(marks_data.as_view())),
    path('login/',csrf_exempt(login.as_view())),
    path('registration/',csrf_exempt(registration.as_view())),
    path('registration_login_data/',csrf_exempt(registration_login_data.as_view())),
    path('delete_account/',csrf_exempt(delete_account.as_view())),
    path('field_data/',csrf_exempt(field_data.as_view())),
    path('user_field_data/',csrf_exempt(user_field_data.as_view())),
    path('politics/',csrf_exempt(politics.as_view())),
    path('politics_get_questions/',csrf_exempt(politics_get_questions.as_view())),
    path('politics_answers/',csrf_exempt(politics_answers.as_view())),
     path('politics_data/',csrf_exempt(politics_data.as_view())),
]