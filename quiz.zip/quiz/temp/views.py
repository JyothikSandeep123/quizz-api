from django.shortcuts import render
from rest_framework.views import APIView
from temp.connections.add_questions import post_question_data
from temp.connections.answers import post_answer_data
from temp.connections.get_questions import get_questions_data
from temp.connections.user_answers import post_user_answers_data
from temp.connections.quiz_marks import get_answers_data
from temp.connections.login_data import  post_login_data
from temp.connections.registration_data import  post_registration_data
from temp.connections.registration_login import  post_registration_data
from temp.connections.delete_account import  post_delete_data
from temp.connections.quiz_fields import  post_field_data
from temp.connections.user_required_field import  post_field_data
from temp.connections.post_politics_answers import post_user_answers_data
from temp.connections.politics_score import get_answers_data
# Create your views here.
from temp.connections.politics_questions import  post_field_data
class question_data(APIView):
    def post(self, request, format=None):
        return post_question_data(request)
class answer_data(APIView):
    def post(self, request, format=None):
        return post_answer_data(request)      
class questions_get_data(APIView):
    def get(self,request):
        return get_questions_data(request) 
class user_answers1(APIView):
    def post(self, request, format=None):
        return post_user_answers_data(request)    
class marks_data(APIView):
    def get(self,request):
        return get_answers_data(request)     
class login(APIView):
    def post(self, request,format=None):
        return post_login_data(request)
class registration(APIView):
    def post(self, request,format=None):
        return post_registration_data(request)    
class registration_login_data(APIView):
    def post(self, request,format=None):
        return post_registration_data(request)
class delete_account(APIView):
    def post(self, request,format=None):
        return post_delete_data(request)  
class field_data(APIView):
    def post(self, request,format=None):
        return post_field_data(request) 
class user_field_data(APIView):      
    def post(self, request,format=None):
        return post_field_data(request)  
class politics(APIView):
    def post(self, request,format=None):
        return post_field_data(request) 
class politics_get_questions(APIView):
    def get(self,request):
        return get_questions_data(request)  
class politics_answers(APIView):
    def post(self,request):
        return post_user_answers_data(request)
class politics_data(APIView):
    def get(self,request):
        return get_answers_data(request)       
#class limit_data1(APIView):
 #   def get(self,request):
  #      return post_limit_data(request)           